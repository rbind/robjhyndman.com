### Name: plot.likert
### Title: Likert-scale data plot
### Aliases: plot.likert plot.likert boxplot.likert
### Keywords: hplot

### ** Examples

x <- c(rep(3,9),rep(4,7),rep(5,14))
y <- likert(x)
plot(y,percent=TRUE)
boxplot(y)

# Side-by-side boxplots
y2 <- likert(sample(1:5,20,TRUE))
boxplot(list(y,y2))



