### Name: summary.likert
### Title: Summary meaasures of Likert scale data
### Aliases: summary.likert
### Keywords: classes

### ** Examples

x <- c(rep(3,9),rep(4,7),rep(5,14))
y <- likert(x)
summary(y)



