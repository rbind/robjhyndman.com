# Create methods for some common functions

sd <- function(...) UseMethod("sd")
var <- function(...) UseMethod("var")
table <- function(...) UseMethod("table")

# Redefine default behaviour
# These are copies of the existing functions in the base package


sd.default <- function (x, na.rm = FALSE, ...) 
{
    if (is.matrix(x)) 
        apply(x, 2, sd, na.rm = na.rm)
    else if (is.vector(x)) 
        sqrt(var(x, na.rm = na.rm))
    else if (is.data.frame(x)) 
        sapply(x, sd, na.rm = na.rm)
    else sqrt(var(as.vector(x), na.rm = na.rm))
}

var.default <- function (x, y = NULL, na.rm = FALSE, use, ...) 
{
    if (missing(use)) 
        use <- if (na.rm) 
            "complete.obs"
        else "all.obs"
    na.method <- pmatch(use, c("all.obs", "complete.obs", "pairwise.complete.obs"))
    if (is.data.frame(x)) 
        x <- as.matrix(x)
    else stopifnot(is.atomic(x))
    if (is.data.frame(y)) 
        y <- as.matrix(y)
    else stopifnot(is.atomic(y))
    .Internal(cov(x, y, na.method, FALSE))
}

table.default <- function (..., exclude = c(NA, NaN), dnn = list.names(...), deparse.level = 1)
{
    list.names <- function(...) {
        l <- as.list(substitute(list(...)))[-1]
        nm <- names(l)
        fixup <- if (is.null(nm))
            seq_along(l)
        else nm == ""
        dep <- sapply(l[fixup], function(x) switch(deparse.level +
            1, "", if (is.symbol(x))
            as.character(x)
        else "", deparse(x)[1]))
        if (is.null(nm))
            dep
        else {
            nm[fixup] <- dep
            nm
        }
    }
    args <- list(...)
    if (length(args) == 0)
        stop("nothing to tabulate")
    if (length(args) == 1 && is.list(args[[1]])) {
        args <- args[[1]]
        if (length(dnn) != length(args))
            dnn <- if (!is.null(argn <- names(args)))
                argn
            else paste(dnn[1], 1:length(args), sep = ".")
    }
    bin <- 0L
    lens <- NULL
    dims <- integer(0)
    pd <- 1L
    dn <- NULL
    for (a in args) {
        if (is.null(lens))
            lens <- length(a)
        else if (length(a) != lens)
            stop("all arguments must have the same length")
        cat <- if (is.factor(a)) {
            if (!missing(exclude)) {
                ll <- levels(a)
                factor(a, levels = ll[!(ll %in% exclude)], exclude = if (is.null(exclude))
                  NULL
                else NA)
            }
            else a
        }
        else factor(a, exclude = exclude)
        nl <- length(ll <- levels(cat))
        dims <- c(dims, nl)
        dn <- c(dn, list(ll))
        bin <- bin + pd * (as.integer(cat) - 1L)
        pd <- pd * nl
    }
    names(dn) <- dnn
    bin <- bin[!is.na(bin)]
    if (length(bin))
        bin <- bin + 1L
    y <- array(tabulate(bin, pd), dims, dimnames = dn)
    class(y) <- "table"
    y
}
