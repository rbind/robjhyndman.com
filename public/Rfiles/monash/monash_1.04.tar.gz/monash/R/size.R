ls.size <- function()
{
	.z <- sapply(ls(.GlobalEnv), function(.x){object.size(get(.x))})
	if(length(.z)>0)
	{
		.tmp <- as.matrix(rev(sort(.z)))
		colnames(.tmp) <- "Size"
		return(.tmp)
	}
	else
		return(invisible())
}
