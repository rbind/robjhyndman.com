# Create methods for some common functions

sd <- function(...) UseMethod("sd")
var <- function(...) UseMethod("var")
table <- function(...) UseMethod("table")

# Redefine default behaviour

sd.default <- function (x, na.rm = FALSE, ...) 
{
    stats:::sd(x,na.rm)
}

var.default <- function (x, y = NULL, na.rm = FALSE, use, ...) 
{
    stats:::var(x,y,na.rm,use)
}

table.default <- function (...) 
{
    base:::table(...)
}
