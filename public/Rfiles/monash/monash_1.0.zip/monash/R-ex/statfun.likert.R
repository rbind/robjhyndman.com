### Name: statfun.likert
### Title: Descriptive statistics for Likert-scale data
### Aliases: mean.likert median.likert quantile.likert sd.likert var.likert
###   sir
### Keywords: classes

### ** Examples

x <- c(rep(3,9),rep(4,7),rep(5,14))
y <- likert(x)
mean(y)
median(y)
quantile(y)
sd(y)
var(y)
sir(y)



