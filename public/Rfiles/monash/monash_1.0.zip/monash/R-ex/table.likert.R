### Name: table.likert
### Title: Likert-scale data table
### Aliases: table.likert tablepc
### Keywords: classes

### ** Examples

## Let x be a set of responses to 5-point Likert scale questions
x <- c(rep(3,9),rep(4,7),rep(5,14))
y <- likert(x)
table(y)
tablepc(y)



