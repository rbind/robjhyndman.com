### Name: print.likert
### Title: Print Likert-scale data
### Aliases: print.likert
### Keywords: classes

### ** Examples

## Let x be a set of responses to 5-point Likert scale questions
x <- c(rep(3,9),rep(4,7),rep(5,14))
y <- likert(x)
print(y)



