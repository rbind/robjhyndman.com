### Function to save eps or pdf figures

savefig <- function (filename, height=10, width = (1 + sqrt(5))/2*height, type=c("eps","pdf","jpg"), pointsize = 10, family = "Helvetica", 
    sublines = 0, toplines = 0, leftlines = 0) 
{
    type <- match.arg(type)
    filename <- paste(filename, ".", type, sep = "")
    if(type=="eps")
    {
        postscript(file = filename, horizontal = FALSE, 
                width = width/2.54, height = height/2.54, pointsize = pointsize, 
                family = family, onefile = FALSE, print.it = FALSE)
    }
    else if(type=="pdf")
    {
        pdf(file = filename, width=width/2.54, height=height/2.54, pointsize=pointsize,
            family=family, onefile=TRUE)
    }
    else if(type=="jpg")
    {
        jpeg(file=filename, width=width*50, height=height*50, pointsize=pointsize*50, quality=100)
    }
    else
        stop("Unknown file type")
    par(mgp = c(2.2, 0.45, 0), tcl = -0.4, mar = c(3.2 + sublines + 0.25 * (sublines > 0), 
         3.5 + leftlines, 1 + toplines + 2*(type=="png"), 1) + 0.1)
    par(pch = 1)
    invisible()
}
