# Create object of class "likert"
likert <- function(x,upper=max(x),labels)
{
    if(missing(labels))
    {
        if(upper==5)
            labels=paste(1:upper,c("Strongly disagree","Disagree","Neutral","Agree","Strongly agree"))
        else if(upper==3)
            labels=c("Disagree","Neutral","Agree")
        else
            labels=paste(1:upper)
    }
    return(structure(list(data=x,upper=upper,labels=labels),class="likert"))
}

# Basic printing, summary and table functions

print.likert <- function(x)
{
    print(table(x))
    print(tablepc(x))
}

summary.likert <- function(x)
{
    output <- numeric(8)
    xf <- factor(x$data,levels=1:x$upper)
    output[1] <- mean(x$data)
    output[2] <- sd(x$data)
    qq <- c(.1,.25,.5,.75,.9)
    output[3:7] <- quantile(x,qq)
    output[8] <- sir(x)
    names(output) <- c("Mean", "StDev",paste(qq,"%",sep=""),"SIR")
    print(x)
    cat("\n")
    return(output)
}

table.likert <- function(x)
{
    x <- factor(x$data,levels=1:x$upper,labels=x$labels)
    return(table(x,dnn="Number"))
}

tablepc <- function(x,sort=FALSE)
{
    if(class(x)=="likert")
        x <- factor(x$data,levels=1:x$upper,labels=x$labels)
    tab <- table(x,dnn="Percent")
    tab <- tab/sum(tab)*100
    if(sort)
        tab <- sort(tab,decreasing=TRUE)
    return(tab)
}


# Plotting function

plot.likert <- function(x,labels=x$labels,percent=FALSE,
    col="grey",xlab=ifelse(percent,"Percent","Number"),...)
{
    oldmar <- par()$mar
    par(mar=c(oldmar[1],10,oldmar[3],oldmar[4]))
    if(percent)
        barplot(tablepc(x),horiz=TRUE,las=1,col=col,xlab=xlab,...)
    else
        barplot(table(x),horiz=TRUE,las=1,col=col,xlab=xlab,...)
    par(mar=oldmar)
    invisible()
}


boxplot.likert <- function(x,...)
{
    stat <- boxplot.stats(x$data)
    qq <- quantile(x,c(.25,.5,.75))
    iqr <- qq[3]-qq[1]
    lo <- min(x$data[x$data >= qq[1] - 1.5*iqr])
    hi <- max(x$data[x$data <= qq[3] + 1.5*iqr])
    stat$stats <- matrix(c(lo,qq,hi))
    bxp(stat,...)
}


boxplot.list <- function(x,...)
{
    if(class(x[[1]])!="likert")
        boxplot.default(x,...)
    else
    {
        newx <- list()
        for(i in 1:length(x))
            newx[[i]] <- x[[1]]$data
        stat <- boxplot.default(newx,...,plot=FALSE)
        for(i in 1:length(x))
        {
            qq <- quantile(x[[i]],c(.25,.5,.75))
            iqr <- qq[3]-qq[1]
            lo <- min(x[[i]]$data[x[[i]]$data >= qq[1] - 1.5*iqr])
            hi <- max(x[[i]]$data[x[[i]]$data <= qq[3] + 1.5*iqr])
            stat$stats[,i] <- c(lo,qq,hi)
        }
        bxp(stat,...)
    }
}
   


# Statistical functions

mean.likert <- function(x,na.rm=FALSE){mean(x$data)}
sd.likert <- function(x,na.rm=FALSE){sd(x$data)}
var.likert <- function(x,na.rm=FALSE){var(x$data)}
median.likert <- function(x,na.rm=FALSE){quantile(x,.5)}

# Pseudo-quantile of Likert-scale data
# Assumes each response represents an underlying continuous
# variable from x-0.5 to x+0.5

quantile.likert <- function(x,probs=seq(0, 1, 0.25),truncate=FALSE)
{
    upper <- x$upper
    x <- x$data
    if(sum(abs(x-round(x)))>0)
        stop("Data not all integer")
    else if(min(x) < 1)
        stop("Data not all positive")
        
    p <- numeric(upper)
    for(i in 1:upper)
        p[i] <- sum(x==i)
    p <- c(0,cumsum(p)/sum(p))
    np <- length(probs)
    i <- output <- numeric(np)
    for(j in 1:np)
    {
        k <- (p < probs[j])
        if(sum(k)>0)
        {
            i <- max((0:upper)[k])+1
            output[j] <- (probs[j]-p[i])/(p[i+1]-p[i]) + i - 0.5
        }
    }
    names(output) <- paste(probs*100,"%",sep="")
    if(truncate)
        output <- pmin(pmax(output,1),upper)
    return(output)
}

sir <- function(x)
{
    out <- diff(quantile(x,c(.25,.75)))/2
    names(out) <- NULL
    return(out)
}
